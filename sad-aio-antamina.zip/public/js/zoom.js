mediumZoom('.zoom',{
    scrollOffset: 100
})